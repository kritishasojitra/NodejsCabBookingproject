const mongoose=require('mongoose');

const signSchema=mongoose.Schema({
          username:{
            type:String,
            require:true
          },
          password:{
            type:String,
            require:true
          }
})

const singtable=mongoose.model('singtable',signSchema);
module.exports=singtable;