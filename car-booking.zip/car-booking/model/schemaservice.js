const mongoose=require('mongoose')

const schemaservice =mongoose.Schema({
    name:{
        type:String,
        // required:true
    },
    number:{
        type:String,
        // required:true
    },
    image:{
        type:String,
        required:true
    }
})

const servicetable=mongoose.model('servicetable',schemaservice);

module.exports=servicetable;