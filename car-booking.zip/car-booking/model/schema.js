const mongoose=require('mongoose')

const schema =mongoose.Schema({
    name:{
        type:String,
        // required:true
    },
    number:{
        type:String,
        // required:true
    },
    email:{
        type:String,
        // required:true
    },
    form:{
        type:String,
        // required:true
    },
    des:{
        type:String,
        // required:true
    },
    car:{
        type:String,
        // required:true
    },
    pa:{
        type:String,
        // required:true
    },
    pd:{
        type:String,
        // required:true
    },
})

const cartable=mongoose.model('cartable',schema);

module.exports=cartable;