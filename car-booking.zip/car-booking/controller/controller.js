const singtable = require("../model/loginschema")
const cartable = require("../model/schema")
const servicetable = require("../model/schemaservice")


const home=(req,res)=>{
    res.render('home')
}
const Home=(req,res)=>{
    res.render('home')
}
const booking=(req,res)=>{
    res.render('booking')
}

const insert=(req,res)=>{

    console.log(req.body);
 

    cartable.create({
        name:req.body.name,
        number:req.body.number,
        email:req.body.email,
        form:req.body.form,
        des:req.body.des,
        car:req.body.car,
        pa:req.body.pa,
        pd:req.body.pd,
        
    }).then(()=>{
        console.log("Data insert.....");
       return res.redirect('/booking')
    })
}

const table=(req,res)=>{

    cartable.find({}).then((alldata)=>{
        res.render('table',{
            data: alldata
        })
    })
    
}

const Delete=(req,res)=>{

    let id=req.query.id;

    cartable.findByIdAndDelete(id)
    .then(()=>{
        console.log("Data Delete....");
        res.redirect('/table')
    })
}

const Edit=(req,res)=>{

    let id=req.query.id;

    cartable.findById(id)
    .then((alldata)=>{
        res.render('edit',{
            edit:alldata
        })
    })
   
}
const update=(req,res)=>{
    let id=req.body.id;


    if(req.file)
    {
        var data={
            name:req.body.name,
            number:req.body.number,
            email:req.body.email,
            form:req.body.form,
            des:req.body.des,
            car:req.body.car,
            pa:req.body.pa,
            pd:req.body.pd,
            // image:req.file.path
        }
    }
    else{

        var data={
            name:req.body.name,
            number:req.body.number,
            email:req.body.email,
            form:req.body.form,
            des:req.body.des,
            car:req.body.car,
            pa:req.body.pa,
            pd:req.body.pd,
        }
    }

    cartable.findByIdAndUpdate(id,data)
    .then((updatedData) => {
        console.log("data update....");
        return res.redirect('/table')
    })
}

const About=(req,res)=>{
    res.render('about')
}

const service=(req,res)=>{
    res.render('services')
}

const serviceadd=(req,res)=>{

    console.log(req.body);
    console.log(req.file);

    servicetable.create({
        name:req.body.name,
        number:req.body.number,
        image:req.file.path
    }).then(()=>{
        console.log("Data insert.....");
       res.redirect('/service')
    })
}

const stable=(req,res)=>{

    servicetable.find({}).then((alldata)=>{
        res.render('sstable',{
            data:alldata
        })
    })
}

const sDelete=(req,res)=>{

    let id=req.query.id;
    console.log(id);

    servicetable.findByIdAndDelete(id)
    .then(()=>{
        console.log("Data Delete....");
        res.redirect('/sstable')
    })
}

const tableedit=(req,res)=>{

    let id=req.query.id;
    console.log(id);

    servicetable.findById(id).then((alldata)=>{
        res.render('tableedit',{
            edit:alldata
        })
    })
}

const update1=(req,res)=>{
    let id=req.body.id;

    console.log(req.file)

    if(req.file)
    {
        var data={
            name:req.body.name,
            number:req.body.number,
            image:req.file.path
        }
    }
    else{

        var data={
            name:req.body.name,
            number:req.body.number,
        }
    }

    servicetable.findByIdAndUpdate(id,data)
    .then((updatedData) => {
        console.log("data update....");
        return res.redirect('/sstable')
    })
}

const singup=(req,res)=>{
    res.render('singnup')
}

const Login=(req,res)=>{
    res.render('login')
}
const sing=(req,res)=>{

    singtable.create(req.body)
    res.redirect('/log')
}

module.exports={
    home,
    Home,
    booking,
    insert,
    table,
    Delete,
    Edit,
    update,
    About,
    service,
    serviceadd,
    stable,
    sDelete,
    tableedit,
    update1,
    singup,
    Login,sing
}