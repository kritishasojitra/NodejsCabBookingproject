const express=require('express')
const controller = require('../controller/controller');
const multer=require('multer');
const routers = express.Router();


const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./uploads')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname)
    }
})

const upload=multer({storage:storage}).single('image')



routers.get('/home',controller.home);
routers.get('/home',controller.Home);
routers.get('/booking',controller.booking);
routers.post('/insert',controller.insert);
routers.get('/table',controller.table);
routers.get('/delete',controller.Delete);
routers.get('/edit',controller.Edit);
routers.post('/update',controller.update);
routers.get('/about',controller.About);
routers.get('/service',controller.service);
routers.post('/add',upload,controller.serviceadd);
routers.get('/sstable',controller.stable)
routers.get('/delete2',controller.sDelete)
routers.get('/edit2',controller.tableedit);
routers.post('/upadd',upload,controller.update1)
routers.get('/',controller.singup)
routers.post('/sign',controller.sing);
routers.get('/log',controller.Login)

module.exports=routers;