const express=require('express')
const port=2424;

const app = express();
const path = require('path');
const session=require('express-session');


app.use(session({secret:"private-key"}));
const passport=require('passport');
const localauth=require('./middelwere/localauth')

localauth(passport);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded());
app.use('/uploads',express.static(path.join(__dirname, 'uploads')))



app.use(passport.initialize());
app.use(passport.session());

const database=require('./config/database')
const cartable=require('./model/schema');
const servicetable=require('./model/schemaservice');





app.post('/log',passport.authenticate('local'),(req,res)=>{
    res.render('home');
 })



app.use('/',require('./route/router'));


app.set('view engine', 'ejs')


app.listen(port,()=>{
    console.log("server stared at:- " + port);
});